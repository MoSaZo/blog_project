from django.db import models
from django.contrib.auth.models import User

class Post(models.Model):
    POST_STATUS_CHOICES = (
        ('draft', 'Draft'),
        ('published', 'Published'),
        ('rejected', 'Rejected'),
    )

    title = models.CharField(max_length=100)
    content = models.TextField()
    author = models.ForeignKey(User,on_delete=models.CASCADE)
    slug = models.SlugField(max_length=200)
    post_status = models.CharField(max_length=20,default='Draft',choices=POST_STATUS_CHOICES)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.title


class News(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-created']
        verbose_name = "News"
        verbose_name_plural = "News"

    def __str__(self):
        return self.title